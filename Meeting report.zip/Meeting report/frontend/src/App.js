// import React, { useState, useEffect, useRef } from 'react';
// import axios from 'axios';
// import io from 'socket.io-client';
// import './App.css';

// // *** IP سیستم خودتان را اینجا چک کنید ***
// const SERVER_URL = 'https://192.168.2.76:5000'; 

// const socket = io(SERVER_URL);

// function App() {
//   const [step, setStep] = useState(1); 
//   const [isLoginMode, setIsLoginMode] = useState(false);
//   const [userData, setUserData] = useState(null);
//   const [selectedSession, setSelectedSession] = useState(null);
  
//   // --- Step 1: Auth ---
//   const [formData, setFormData] = useState({ full_name: '', email: '', phone: '', company: '' });
//   const [msg, setMsg] = useState('');

//   const handleAuth = async (e) => {
//     e.preventDefault();
//     const url = isLoginMode ? `${SERVER_URL}/login` : `${SERVER_URL}/register`;
//     try {
//       const res = await axios.post(url, formData);
//       setUserData({ id: res.data.user_id, name: res.data.user_name, email: res.data.email });
//       setStep(2); setMsg('');
//     } catch (err) { setMsg(err.response?.data?.message || 'خطا در اتصال (IP یا فایروال را چک کنید)'); }
//   };

//   // --- Step 2: List (اصلاح شده) ---
//   const [meetings, setMeetings] = useState([]);
  
//   useEffect(() => {
//     // فقط وقتی در مرحله ۲ هستیم لیست جلسات را بگیر
//     if (step === 2) {
//       axios.get(`${SERVER_URL}/meetings`)
//         .then(res => setMeetings(res.data))
//         .catch(console.error);
//     }
//   }, [step]);

//   const joinMeeting = async (session) => {
//     try {
//       const res = await axios.post(`${SERVER_URL}/join_meeting`, {
//         user_id: userData.id, email: userData.email, session_id: session.id
//       });
//       setSelectedSession({ ...session, meet_id: res.data.meet_id });
      
//       // اتصال به اتاق سوکت
//       socket.emit('join', { session_id: session.id });
      
//       setStep(3);
//     } catch (err) { alert('خطا در ورود به جلسه'); }
//   };

//   // --- Step 3: Room (Live Audio) ---
//   const [members, setMembers] = useState([]);
//   const [isRecording, setIsRecording] = useState(false);
//   const [savedTranscripts, setSavedTranscripts] = useState([]); 
//   const [liveText, setLiveText] = useState(''); 

//   const mediaRecorderRef = useRef(null);
//   const audioChunksRef = useRef([]);
//   const recognitionRef = useRef(null);

//   // --- پخش صدای زنده (با مدیریت خطا) ---
//   useEffect(() => {
//     socket.on('play_audio', (data) => {
//       try {
//         const audioBlob = new Blob([data.audio], { type: 'audio/webm;codecs=opus' });
//         if (audioBlob.size < 200) return; 

//         const audioUrl = URL.createObjectURL(audioBlob);
//         const audio = new Audio(audioUrl);
        
//         const playPromise = audio.play();
//         if (playPromise !== undefined) {
//           playPromise.catch(error => {
//             // خطاهای ریز پخش را نادیده بگیر
//           });
//         }
//       } catch (e) {
//         console.error("Error playing audio chunk", e);
//       }
//     });

//     return () => {
//       socket.off('play_audio');
//     };
//   }, []);

//   // دریافت لیست اعضا
//   useEffect(() => {
//     if (step === 3 && selectedSession) {
//       const fetchMembers = () => {
//         axios.get(`${SERVER_URL}/meeting_members/${selectedSession.id}`).then(res => setMembers(res.data));
//       };
//       fetchMembers();
//       const interval = setInterval(fetchMembers, 5000);
//       return () => clearInterval(interval);
//     }
//   }, [step, selectedSession]);

//   const startRecording = async () => {
//     try {
//       const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
//       let options = { mimeType: 'audio/webm;codecs=opus' };
//       if (!MediaRecorder.isTypeSupported(options.mimeType)) {
//          options = { mimeType: 'audio/webm' };
//       }

//       mediaRecorderRef.current = new MediaRecorder(stream, options);
//       audioChunksRef.current = [];

//       mediaRecorderRef.current.ondataavailable = (e) => { 
//         if (e.data.size > 0) {
//           audioChunksRef.current.push(e.data);
//           socket.emit('voice_stream', {
//             session_id: selectedSession.id,
//             audio: e.data
//           });
//         }
//       };

//       mediaRecorderRef.current.onstop = sendAudioToSave;
//       mediaRecorderRef.current.start(2000); 

//       if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
//          const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
//          recognitionRef.current = new SpeechRecognition();
//          recognitionRef.current.continuous = true;
//          recognitionRef.current.interimResults = true;
//          recognitionRef.current.lang = 'fa-IR';
//          recognitionRef.current.onresult = (event) => {
//            let interimTranscript = '';
//            for (let i = event.resultIndex; i < event.results.length; ++i) {
//              if (!event.results[i].isFinal) interimTranscript += event.results[i][0].transcript;
//            }
//            setLiveText(interimTranscript);
//          };
//          recognitionRef.current.start();
//       }

//       setIsRecording(true);
//     } catch (err) { alert('دسترسی میکروفون رد شد'); }
//   };

//   const stopRecording = () => {
//     if (mediaRecorderRef.current) mediaRecorderRef.current.stop();
//     if (recognitionRef.current) recognitionRef.current.stop();
//     setIsRecording(false);
//     setLiveText('');
//   };

//   const sendAudioToSave = async () => {
//     const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
//     const data = new FormData();
//     data.append('file', audioBlob, "voice.webm");
//     data.append('user_id', userData.id);
//     data.append('meet_id', selectedSession.meet_id);

//     try {
//       const res = await axios.post(`${SERVER_URL}/upload_audio`, data);
//       setSavedTranscripts(prev => [...prev, { user: userData.name, text: res.data.text_preview, time: new Date().toLocaleTimeString() }]);
//     } catch (err) { console.error(err); }
//   };

//   // --- Step 4: Report ---
//   const [reportData, setReportData] = useState([]);
  
//   useEffect(() => {
//     // فقط وقتی در مرحله ۴ هستیم گزارش را بگیر
//     if (step === 4 && selectedSession) {
//       // *** تغییر مهم: ارسال my_meet_id به عنوان پارامتر ***
//       axios.get(`${SERVER_URL}/get_session_records/${selectedSession.id}?my_meet_id=${selectedSession.meet_id}`)
//         .then(res => setReportData(res.data))
//         .catch(console.error);
//     }
//   }, [step, selectedSession]);

//   const downloadWord = () => {
//     window.open(`${SERVER_URL}/download_word/${selectedSession.id}`, '_blank');
//   };

//   return (
//     <div className="app-root">
//       {step === 1 && (
//         <div className="container">
//           <div className="form-card">
//             <div className="toggle-container">
//               <button className={`toggle-btn ${!isLoginMode ? 'active' : ''}`} onClick={() => setIsLoginMode(false)}>ثبت نام</button>
//               <button className={`toggle-btn ${isLoginMode ? 'active' : ''}`} onClick={() => setIsLoginMode(true)}>ورود</button>
//             </div>
//             <h2>{isLoginMode ? 'ورود' : 'ثبت نام'}</h2>
//             <form onSubmit={handleAuth}>
//               {!isLoginMode && <div className="form-group"><label>نام</label><input type="text" value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})} required /></div>}
//               <div className="form-group"><label>ایمیل</label><input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} required /></div>
//               {!isLoginMode && <><div className="form-group"><label>تلفن</label><input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} /></div><div className="form-group"><label>شرکت</label><input type="text" value={formData.company} onChange={e => setFormData({...formData, company: e.target.value})} /></div></>}
//               <button type="submit" className="submit-btn">{isLoginMode ? 'ورود' : 'ثبت نام'}</button>
//             </form>
//             {msg && <p className="message error">{msg}</p>}
//           </div>
//         </div>
//       )}

//       {step === 2 && (
//         <div className="container">
//           <div className="meeting-list-card">
//             <h2>لیست جلسات</h2>
//             <div className="meetings-grid">
//               {meetings.map(meet => (
//                 <div key={meet.id} className="meeting-item">
//                   <h3>{meet.title}</h3>
//                   <p>{meet.description}</p>
//                   <button className="join-btn" onClick={() => joinMeeting(meet)}>ورود</button>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </div>
//       )}

//       {step === 3 && (
//         <div className="room-container">
//           <div className="room-main">
//             <div className="recorder-box">
//               <h2>{selectedSession.title}</h2>
//               <div className="mic-section">
//                 {!isRecording ? <button className="mic-btn start" onClick={startRecording}>🎙️</button> : <button className="mic-btn stop" onClick={stopRecording}>⏹️</button>}
//                 <p>{isRecording ? 'در حال پخش زنده...' : 'برای صحبت کلیک کنید'}</p>
//               </div>
//               <div className="live-transcript-box">
//                 <h4>متن صحبت‌های شما:</h4>
//                 <div className="transcript-content">
//                   {savedTranscripts.map((t, i) => <div key={i} className="transcript-item saved"><span className="user-label">{t.user}:</span> {t.text}</div>)}
//                   {isRecording && liveText && <div className="transcript-item live"><span className="user-label">{userData.name}:</span> <span className="typing-text"> {liveText}</span></div>}
//                 </div>
//               </div>
//               <div className="action-buttons">
//                 <button className="report-btn" onClick={() => setStep(4)}>📄 گزارش</button>
//                 <button className="back-btn" onClick={() => setStep(2)}>خروج</button>
//               </div>
//             </div>
//           </div>
//           <div className="room-sidebar">
//             <h3>اعضا</h3>
//             <ul>{members.map((m, i) => <li key={i}><span className="avatar">👤</span><div className="info"><span className="name">{m.user_name}</span></div></li>)}</ul>
//           </div>
//         </div>
//       )}

//       {step === 4 && (
//         <div className="container">
//           <div className="report-card">
//             <div className="report-header"><h2>گزارش جلسه</h2><button className="download-btn" onClick={downloadWord}>📥 دانلود Word</button></div>
//             <div className="report-list">
//               {reportData.map((item, index) => <div key={index} className="report-item"><span className="report-time">{item.time}</span><p className="report-text"><strong>{item.user_name}:</strong> {item.text}</p></div>)}
//             </div>
//             <button className="back-btn" onClick={() => setStep(3)}>بازگشت</button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;




















import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import './App.css';

// *** نکته برای ارسال به رئیس: ***
// چون رئیس شما روی سیستم خودش اجرا می‌کند، بهتر است این را روی localhost بگذارید.
// مگر اینکه بخواهید روی شبکه شرکت تست کنید.
const SERVER_URL = 'https://localhost:5000'; 

const socket = io(SERVER_URL);

function App() {
  const [step, setStep] = useState(1); 
  const [isLoginMode, setIsLoginMode] = useState(false);
  const [userData, setUserData] = useState(null);
  const [selectedSession, setSelectedSession] = useState(null);
  
  // --- Step 1: Auth ---
  const [formData, setFormData] = useState({ full_name: '', email: '', phone: '', company: '' });
  const [msg, setMsg] = useState('');

  const handleAuth = async (e) => {
    e.preventDefault();
    const url = isLoginMode ? `${SERVER_URL}/login` : `${SERVER_URL}/register`;
    try {
      const res = await axios.post(url, formData);
      setUserData({ id: res.data.user_id, name: res.data.user_name, email: res.data.email });
      setStep(2); setMsg('');
    } catch (err) { setMsg(err.response?.data?.message || 'خطا در اتصال'); }
  };

  // --- Step 2: List (اصلاح شد) ---
  const [meetings, setMeetings] = useState([]);
  
  useEffect(() => {
    // *** اصلاحیه ۱: اینجا قبلاً اشتباهی کد گزارش را گذاشته بودید ***
    if (step === 2) {
      axios.get(`${SERVER_URL}/meetings`)
        .then(res => setMeetings(res.data))
        .catch(console.error);
    }
  }, [step]);

  const joinMeeting = async (session) => {
    try {
      const res = await axios.post(`${SERVER_URL}/join_meeting`, {
        user_id: userData.id, email: userData.email, session_id: session.id
      });
      // ذخیره meet_id برای فیلتر کردن پیام‌های قدیمی
      setSelectedSession({ ...session, meet_id: res.data.meet_id });
      
      socket.emit('join', { session_id: session.id });
      setStep(3);
    } catch (err) { alert('خطا در ورود به جلسه'); }
  };

  // --- Step 3: Room (Live Audio) ---
  const [members, setMembers] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [savedTranscripts, setSavedTranscripts] = useState([]); 
  const [liveText, setLiveText] = useState(''); 

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const recognitionRef = useRef(null);

  // پخش صدا
  useEffect(() => {
    socket.on('play_audio', (data) => {
      try {
        const audioBlob = new Blob([data.audio], { type: 'audio/webm;codecs=opus' });
        if (audioBlob.size < 200) return; 
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        const playPromise = audio.play();
        if (playPromise !== undefined) { playPromise.catch(() => {}); }
      } catch (e) { console.error(e); }
    });
    return () => { socket.off('play_audio'); };
  }, []);

  // دریافت اعضا
  useEffect(() => {
    if (step === 3 && selectedSession) {
      const fetchMembers = () => {
        axios.get(`${SERVER_URL}/meeting_members/${selectedSession.id}`).then(res => setMembers(res.data));
      };
      fetchMembers();
      const interval = setInterval(fetchMembers, 5000);
      return () => clearInterval(interval);
    }
  }, [step, selectedSession]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      let options = { mimeType: 'audio/webm;codecs=opus' };
      if (!MediaRecorder.isTypeSupported(options.mimeType)) options = { mimeType: 'audio/webm' };

      mediaRecorderRef.current = new MediaRecorder(stream, options);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (e) => { 
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
          socket.emit('voice_stream', { session_id: selectedSession.id, audio: e.data });
        }
      };

      mediaRecorderRef.current.onstop = sendAudioToSave;
      mediaRecorderRef.current.start(2000); 

      if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
         const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
         recognitionRef.current = new SpeechRecognition();
         recognitionRef.current.continuous = true;
         recognitionRef.current.interimResults = true;
         recognitionRef.current.lang = 'fa-IR';
         recognitionRef.current.onresult = (event) => {
           let interimTranscript = '';
           for (let i = event.resultIndex; i < event.results.length; ++i) {
             if (!event.results[i].isFinal) interimTranscript += event.results[i][0].transcript;
           }
           setLiveText(interimTranscript);
         };
         recognitionRef.current.start();
      }
      setIsRecording(true);
    } catch (err) { alert('دسترسی میکروفون رد شد'); }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) mediaRecorderRef.current.stop();
    if (recognitionRef.current) recognitionRef.current.stop();
    setIsRecording(false);
    setLiveText('');
  };

  const sendAudioToSave = async () => {
    const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
    const data = new FormData();
    data.append('file', audioBlob, "voice.webm");
    data.append('user_id', userData.id);
    data.append('meet_id', selectedSession.meet_id);

    try {
      const res = await axios.post(`${SERVER_URL}/upload_audio`, data);
      setSavedTranscripts(prev => [...prev, { user: userData.name, text: res.data.text_preview, time: new Date().toLocaleTimeString() }]);
    } catch (err) { console.error(err); }
  };

  // --- Step 4: Report (اصلاح شد) ---
  const [reportData, setReportData] = useState([]);
  
  useEffect(() => {
    if (step === 4 && selectedSession) {
      // *** اصلاحیه ۲: ارسال my_meet_id برای فیلتر کردن پیام‌های قدیمی ***
      axios.get(`${SERVER_URL}/get_session_records/${selectedSession.id}?my_meet_id=${selectedSession.meet_id}`)
        .then(res => setReportData(res.data))
        .catch(console.error);
    }
  }, [step, selectedSession]);

  const downloadWord = () => {
    window.open(`${SERVER_URL}/download_word/${selectedSession.id}`, '_blank');
  };

  return (
    <div className="app-root">
      {/* STEP 1 */}
      {step === 1 && (
        <div className="container">
          <div className="form-card">
            <div className="toggle-container">
              <button className={`toggle-btn ${!isLoginMode ? 'active' : ''}`} onClick={() => setIsLoginMode(false)}>ثبت نام</button>
              <button className={`toggle-btn ${isLoginMode ? 'active' : ''}`} onClick={() => setIsLoginMode(true)}>ورود</button>
            </div>
            <h2>{isLoginMode ? 'ورود' : 'ثبت نام'}</h2>
            <form onSubmit={handleAuth}>
              {!isLoginMode && <div className="form-group"><label>نام</label><input type="text" value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})} required /></div>}
              <div className="form-group"><label>ایمیل</label><input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} required /></div>
              {!isLoginMode && <><div className="form-group"><label>تلفن</label><input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} /></div><div className="form-group"><label>شرکت</label><input type="text" value={formData.company} onChange={e => setFormData({...formData, company: e.target.value})} /></div></>}
              <button type="submit" className="submit-btn">{isLoginMode ? 'ورود' : 'ثبت نام'}</button>
            </form>
            {msg && <p className="message error">{msg}</p>}
          </div>
        </div>
      )}

      {/* STEP 2 */}
      {step === 2 && (
        <div className="container">
          <div className="meeting-list-card">
            <h2>لیست جلسات</h2>
            <div className="meetings-grid">
              {meetings.map(meet => (
                <div key={meet.id} className="meeting-item">
                  <h3>{meet.title}</h3>
                  <p>{meet.description}</p>
                  <button className="join-btn" onClick={() => joinMeeting(meet)}>ورود</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STEP 3 */}
      {step === 3 && (
        <div className="room-container">
          <div className="room-main">
            <div className="recorder-box">
              <h2>{selectedSession.title}</h2>
              <div className="mic-section">
                {!isRecording ? <button className="mic-btn start" onClick={startRecording}>🎙️</button> : <button className="mic-btn stop" onClick={stopRecording}>⏹️</button>}
                <p>{isRecording ? 'در حال پخش زنده...' : 'برای صحبت کلیک کنید'}</p>
              </div>
              <div className="live-transcript-box">
                <h4>متن صحبت‌های شما:</h4>
                <div className="transcript-content">
                  {savedTranscripts.map((t, i) => <div key={i} className="transcript-item saved"><span className="user-label">{t.user}:</span> {t.text}</div>)}
                  {isRecording && liveText && <div className="transcript-item live"><span className="user-label">{userData.name}:</span> <span className="typing-text"> {liveText}</span></div>}
                </div>
              </div>
              <div className="action-buttons">
                <button className="report-btn" onClick={() => setStep(4)}>📄 گزارش</button>
                <button className="back-btn" onClick={() => setStep(2)}>خروج</button>
              </div>
            </div>
          </div>
          <div className="room-sidebar">
            <h3>اعضا</h3>
            <ul>{members.map((m, i) => <li key={i}><span className="avatar">👤</span><div className="info"><span className="name">{m.user_name}</span></div></li>)}</ul>
          </div>
        </div>
      )}

      {/* STEP 4 */}
      {step === 4 && (
        <div className="container">
          <div className="report-card">
            <div className="report-header"><h2>گزارش جلسه</h2><button className="download-btn" onClick={downloadWord}>📥 دانلود Word</button></div>
            <div className="report-list">
              {reportData.map((item, index) => <div key={index} className="report-item"><span className="report-time">{item.time}</span><p className="report-text"><strong>{item.user_name}:</strong> {item.text}</p></div>)}
            </div>
            <button className="back-btn" onClick={() => setStep(3)}>بازگشت</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;